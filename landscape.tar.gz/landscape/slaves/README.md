Docu is available at [1].

[1]: https://wiki.wdf.sap.corp/wiki/display/hanabuild/_slaves
