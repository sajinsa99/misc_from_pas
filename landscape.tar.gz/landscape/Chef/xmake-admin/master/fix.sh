#!/bin/bash

function fixName  {
  echo "" >> cookbooks/$1/metadata.rb
  echo "name '$1'" >> cookbooks/$1/metadata.rb
}

fixName nano
fixName winstaller
fixName charon

sed -i 's/.*checksum.*//g' cookbooks/sap-jenkins-addons/recipes/jenkins.rb
sed -i 's/.*checksum.*//g' cookbooks/maven/attributes/default.rb
sed -i 's/.*checksum.*//g' cookbooks/sap-jvm/attributes/default.rb

cp -f solo.jef cookbooks/Setup-xMake-Environment
