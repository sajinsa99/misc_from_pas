#export HTTP_PROXY=http://proxy.wdf.sap.corp:8080
#export http_proxy=http://proxy.wdf.sap.corp:8080
