# Configuration for monsoon3
This is the terraform configuration for monsoon3 project [sap-cloud-platform-engineering-services].

If you want to change the number of existing servers, just increase the value at _servers_ in the _main.tf_ file.
```
module "terranova" {
  source = "./server"
  availability_zone = "${var.availability_zone}"
  name = "terracotta"
  image = "${var.image_ubuntu}"
  flavor = "${var.flavor_04_04}"
  servers = 2
}
```

If you do larger changes to the configuration, please try them in branch [terraform_changes].

# Terraform plan
The terraform configuration can be checked by executing _terraform plan_. 
This can be done using the following job depending on the branch.

| branch | job |
| ------ | ---- |
| master | [terraform_plan_master] |
| terraform_changes | [terraform_plan_changes] |

# Terraform apply
To apply the changes to the landscape execute the job [terraform_apply].

# Terraform slave
If there is no terraform slave available you can create one manually.
See [monsoon3 intro] for general instructions (e.g how to create ccloud key pair).
Create [new instance] with following settings:

| key | value |
| --- | ----- |
| Name | terradura |
| Availability zone | eu-de-1b |
| Key pair | ccloud |
| Flavour | m1.small |
| Image | ubuntu-16... |
| Private Network | xmake slaves network |

Allocate [new floating ip] with following settings:

| key | value |
| --- | ----- |
| Floating network | FloatingIP-external-monsoon3-05 |
| Floating subnet | FloatingIP-sap-monsoon3-05-01 |
| Description | terradura |

Go to the instance and attach the floating ip.

Create/Adjust the DNS A record _mo-terradura.hyperland.only.sap_ to point to the floating IP.

To execute the installation of terraform, enter the floating IP in the [landscape.yaml] under _UBUNTU:_

```
UBUNTU:
  Default:
    prepare: UBUNTUMONSOON3 
    Usage: Terraform slave
    Docu: Terraform slave automatically set up
    Profile: [TERRAFORM]
    node_labels: terraform
    node_executors: 1
  terradura.hyperland.only.sap:   
  10.47.228.162:
Docu: Manually set up terraform slave
```
Logon to ld2277 and remove entry for _mo-terradura.hyperland.only.sap_ from _/data/home/prod4000/.ssh/known_hosts_.
Delete slave _mo-terradura.hyperland.only.sap_ if existing on [prod-landscape4000]
Execute [jef_config_processor] to trigger the installation.


# Known bug in Terraform
Don't use
```
some_attr = "${element(some_other_resource.foo.*.some_attr, count.index)}" }}
```
but use
```
some_attr = "${some_other_resource.foo.*.some_attr[count.index]}"
```
See also [3449].

 

[monsoon3]: https://dashboard.eu-de-1.cloud.sap/monsoon3/
[sap-cloud-platform-engineering-services]: https://dashboard.eu-de-1.cloud.sap/monsoon3/sap-cloud-platform-engineering-services/home
[terraform_changes]: https://github.wdf.sap.corp/hana-infrastructure/hanamake_landscape/tree/terraform_changes/terraform
[terraform_plan_master]: https://prod-landscape4000.wdf.sap.corp:4000/view/_terraform/job/_terraform_plan_master/
[terraform_plan_changes]: https://prod-landscape4000.wdf.sap.corp:4000/view/_terraform/job/_terraform_plan_changes/
[terraform_apply]: https://prod-landscape4000.wdf.sap.corp:4000/view/_terraform/job/_terraform_apply/
[pull request]: https://github.wdf.sap.corp/hana-infrastructure/hanamake_landscape/compare/terraform_changes?expand=1
[3449]: https://github.com/hashicorp/terraform/issues/3449
[new instance]: https://dashboard.eu-de-1.cloud.sap/monsoon3/sap-cloud-platform-engineering-services/compute/instances?overlay=new
[new floating ip]: https://dashboard.eu-de-1.cloud.sap/monsoon3/sap-cloud-platform-engineering-services/networking/floating_ips?overlay=new
[monsoon3 intro]: https://github.wdf.sap.corp/hyper-landscape/Documentation/blob/master/usecases/Monsoon3SlaveSetup.md
[landscape.yaml]: https://github.wdf.sap.corp/hana-infrastructure/hanamake_landscape/blob/master/Landscape.yaml
[jef_config_processor]: https://prod-landscape4000.wdf.sap.corp:4000/job/_jef_config_processor
[prod-landscape4000]: https://prod-landscape4000.wdf.sap.corp:4000/computer
