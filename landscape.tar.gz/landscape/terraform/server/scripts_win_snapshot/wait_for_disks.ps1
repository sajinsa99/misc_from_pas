$offline_disks = 0
$attempts = 0
while ($attempts -le 1800) {
  $disk_count = (Get-Disk | Where-Object IsOffline -EQ $true | Measure-Object).Count
  Write-Output "$disk_count offline disks attached"
  if ($disk_count -eq 2) {
    break
  }
  Start-Sleep -s 1
}
Write-Output "Done!"
