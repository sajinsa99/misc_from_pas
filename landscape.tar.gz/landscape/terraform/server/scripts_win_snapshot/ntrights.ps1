import-module .\LHSNTrights.psm1
Set-LHSNTRights -PrivilegeName "SeAssignPrimaryTokenPrivilege" -Identity "pgold"