 #!/bin/bash

instance=$2
if [ -z "$2" ]
then
  exit
fi

mkdir -p admin

function finish {
  rm -f admin/$instance
}

trap finish EXIT


pwd=""

for i in {1..10}
do

  nova-password -i $1 $instance > admin/$instance
  rc=$?
  if [ $rc != 0 ]
  then
    exit $rc
  fi

  pwd=`cat admin/$instance | awk 'FNR == 3 {print $5}'`

  if [ -n "$pwd" ]
  then
    jq -n --arg pwd "$pwd" '{"password":$pwd}'
    exit $?
  fi

  sleep 30

done

exit 1
