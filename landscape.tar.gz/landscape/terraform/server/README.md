Crete a server with floating ip and DNS entry.
Optionally attach up to two disks.
