#!/bin/bash

handle_data_dir=${1:-false}

function error_exit
{
  echo "${1:-"Error Message Not Defined"}"
  exit 1
}

retry=0
max_retry=60
disk_exists=false

if [ $handle_data_dir = true ]
then
  echo "[info] handle_data_dir variable is true"
  if [ -d /data ];
  then
    echo "[info] /data directory exists."
    echo "[info] check if disk /dev/sdb is attached."

    # check if /dev/sdb exists
    if [ -e /dev/sdb ];
    then
      disk_exists=true
    fi
    while true; do
      if [ "$disk_exists" = "false" ] && [ $retry -lt $max_retry ];
      then
        let retry+=1
        echo "[info] /dev/sdb does not exist yet. Try $retry out of $max_retry. Sleeping 10 seconds..."
        sleep 10
        if [ -e /dev/sdb ];
        then
          disk_exists=true
        fi
      else
        break
      fi
    done

    if [ -e /dev/sdb ];
    then
      echo "[info] /dev/sdb exists."
      mounted=`findmnt -o source -T /xmake | grep lv_xmake -c || true`

      if [ $mounted -ne 1 ]
      then
        echo "[info] /xmake volume is not mounted."
        userOwnerShip=`stat -c '%U' /data`
        groupOwnerShip=`stat -c '%G' /data`

        echo "[INFO] Creating /xmake directory"
        sudo chmod 666 /etc/fstab || error_exit  "[ERROR] Can not manipulate fstab";

        sudo /sbin/vgcreate vg_sys_r1 /dev/sdb && echo "[OK] Volume group created" || error_exit  "[ERROR] Cannot create volume group .";
        sudo /sbin/lvcreate -l 100%FREE -n lv_xmake vg_sys_r1 && echo "[OK] Logical volume created" || error_exit  "[ERROR] Cannot create logical volume";
        sudo /sbin/mkfs.xfs /dev/vg_sys_r1/lv_xmake && echo "[OK] Format of partition done" || error_exit  "[ERROR] Cannot format the partition";
        sudo mkdir /xmake && echo "[OK] xmake directory created" || error_exit  "[ERROR] Cannot create xmake directory";
        sudo echo "/dev/vg_sys_r1/lv_xmake /xmake xfs noatime 1 2" >>/etc/fstab
        sudo mount /xmake && echo "[OK] Mount of volume to xmake directory was succesfull" || error_exit  "[ERROR] Cannot mount volume to xmake directory";
        sudo mkdir /xmake/data && echo "[OK] data directory under /xmake is created" || error_exit  "[ERROR] Cannot create data directory under /xmake";
        sudo mv /data/{xmake,home} /xmake/data && echo "[OK] Moving /data/xmake and /data/home contents to /xmake was successfull" || error_exit  "[ERROR] Cannot move /data/xmake and /data/home contents to /xmake";
        sudo mv /data/xtr /xmake/xtr && echo "[OK] Moving /data/xtr contents to /xmake was successfull" || error_exit  "[ERROR] Cannot move /data/xtr contents to /xmake";
        sudo ln -s /xmake/data/xmake /data/xmake && echo "[OK] Linking /data/xmake to /xmake/data/xmake was successfull" || error_exit  "[ERROR] Cannot link /data/xmake to /xmake/data/xmake";
        sudo ln -s /xmake/data/home /data/home && echo "[OK] Linking /data/home to /xmake/data/home was successfull" || error_exit  "[ERROR] Cannot link /data/home to /xmake/data/home";
        sudo ln -s /xmake/xtr /data/xtr && echo "[OK] Linking /data/xtr to /xmake/xtr was successfull" || error_exit  "[ERROR] Cannot link /data/xtr to /xmake/xtr";
        sudo chown -R $userOwnerShip:$groupOwnerShip /xmake && echo "[OK] Change ownership of /xmake directory was successfull" || error_exit  "[ERROR] Cannot change ownership of /xmake directory";
      else
        echo "/xmake volume is already mounted."
      fi
    else
      error_exit  "[ERROR] /dev/sdb is not attached.";
    fi
  else
    error_exit "[ERROR] /data directory does not exist."
  fi

  # Check if linking is done
  if [[ -L "/data/xmake" && -d "/data/xmake" ]]
  then
    echo "/data/xmake symlink is created."
  else
    error_exit "[ERROR] linking /data/xmake to /xmake/data/xmake is not done."
  fi
fi
