#!/bin/bash

sudo mv -f /home/ccloud/ssh_host_rsa_key /etc/ssh/ssh_host_rsa_key
sudo ssh-keygen -f /etc/ssh/ssh_host_rsa_key -y > /home/ccloud/ssh_host_rsa_key.pub
sudo mv /home/ccloud/ssh_host_rsa_key.pub /etc/ssh/ssh_host_rsa_key.pub
sudo chown lroot:root /etc/ssh/ssh_host_rsa_key
sudo chown lroot:root /etc/ssh/ssh_host_rsa_key.pub
sudo chmod 600 /etc/ssh/ssh_host_rsa_key
