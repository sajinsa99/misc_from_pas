#!/bin/bash

handle_docker_custom_config=${1:-false}
docker_disk=/dev/sdc
docker_disk_retry=0
docker_disk_max_retry=60
docker_disk_exist=false
docker_disk_exist_sleep=10
docker_lib_target=/xmake/docker_lib
docker_dm_vg=vg_docker
docker_lvdata=lv_docker_data
docker_lvmetadata=lv_docker_metadata
docker_dm_basesize=40G

function exit_message
{
  local exit_code=$1
  local message=$2

  echo -e "${2:-"Error Message Not Defined\n"}"
  exit "${exit_code}"
}

function service_docker
{
  local action=$1
  echo -e "\nservice docker ${action} requested"
  sudo /usr/sbin/service docker "${action}"
  sleep 5
  echo "Done"
  echo -e  "\nchecking docker running process"
  ps -ef | grep dockerd | grep -v grep
  echo -e "\ndocker service status:"
  sudo /usr/sbin/service docker status
}
echo -e "\n\
******************************\n\
*      Handle Docker         *\n\
******************************\n\
[info] Check handle_docker_custom_config flag\n"
if [ $handle_docker_custom_config != true ]
then
  exit_message 0 "[WARN] handle_docker_partition_config not set into the module.\nexiting...\n"
fi
echo "[success] handle_docker_custom_config is set to $handle_docker_custom_config."


echo "[info] check if docker is installed"
if ! type docker ; then
  exit_message 1 "[error] docker not found on $(hostname). aborting...\n"
fi
echo "[success] docker found."

echo "[info] Check if devicemapper is already set on docker."
if [[ $(sudo docker info 2>/dev/null | grep -i "Storage Driver:" | grep -o '[^ ]*$') = "devicemapper" ]] ; then
  exit_message 0 "[WARN] devicemapper already configured. aborting ..."
fi

echo "[info] Check if ${docker_disk} exists."
while [[ "${docker_disk_exist}" = false ]]; do
  if [ -e "${docker_disk}" ]; then
    docker_disk_exist=true
    continue
  fi
  if [ $docker_disk_retry -lt $docker_disk_max_retry ]; then
    let docker_disk_retry+=1
    echo "[info] ${docker_disk} does not exist yet. Try ${docker_disk_retry} out of ${docker_disk_max_retry}. Sleeping ${docker_disk_exist_sleep} seconds..."
    sleep ${docker_disk_exist_sleep}
  else
    exit_message 1 "[error] ${docker_disk} still not exist. aborting...\n"
  fi
done
echo "[success] ${docker_disk} exists."

docker_lib_orig=$(sudo docker info 2>/dev/null | grep -i "Docker Root Dir:" | grep -o '[^ ]*$')

service_docker stop

echo "[info] Set volume group."
sudo /sbin/vgcreate "${docker_dm_vg}" "${docker_disk}" && echo "[success] Volume group created" || exit_message 1 "[error] Cannot create volume group.\n";
echo "[info] Set logical volumes."
sudo /sbin/lvcreate -l 1%FREE -n "${docker_lvmetadata}" "${docker_dm_vg}" && echo "[success] Logical volume ${lv_docker_metadata} created" || exit_message 1  "[error] Cannot create logical volume ${lv_docker_metadata}\n";
sudo /sbin/lvcreate -l 100%FREE -n "${docker_lvdata}" "${docker_dm_vg}" && echo "[success] Logical volume ${lv_docker_data} created" || exit_message 1  "[error] Cannot create logical volume ${lv_docker_data}\n";

echo "[info] set custom docker data directory."
sudo cp /etc/docker/daemon.json /etc/docker/daemon.json.orig
sudo jq -r --arg docker_lib "${docker_lib_target}" '. |= . + {"data-root": $docker_lib}' /etc/docker/daemon.json > /tmp/daemon.json
sudo cp /tmp/daemon.json /etc/docker/daemon.json

echo "[info] clean old docker data directory."
rm -rf "${docker_lib_orig}/*"

echo "[info] set devicemapper for docker."
sudo jq --arg data "dm.datadev=/dev/${docker_dm_vg}/${docker_lvdata}"\
        --arg metadata "dm.metadatadev=/dev/${docker_dm_vg}/${docker_lvmetadata}"\
        --arg basesize "dm.basesize=${docker_dm_basesize}" \
        '. |= . + {"storage-driver": "devicemapper"} + {"storage-opts": [ $data, $metadata, $basesize ]}' /etc/docker/daemon.json > /tmp/daemon.json
sudo cp /tmp/daemon.json /etc/docker/daemon.json

service_docker start

echo "[INFO] Check docker state."
[ $(sudo /usr/sbin/service docker status | grep Active | awk '{print $2}') = "active" ] || exit_message 1 "[error] docker not started as expected."

exit_message 0 "[success] $0 completed\n"