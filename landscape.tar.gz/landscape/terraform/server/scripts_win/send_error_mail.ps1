param(
[string]$attachment)

$hostname = hostname
$recipients = @("k.arnold@sap.com, DL_5A539AB67BCF840DAA000033@global.corp.sap, DL_011000358700001376642008F@global.corp.sap")
Send-MailMessage -From "noreply@sap.com" `
-To "$recipients" `
-Subject "Init failed on $hostname" `
-SmtpServer  'mail.sap.corp' `
-BODY "Init scripts failed on $hostname. See attached log file for details. Further action is only required by the person who created the instance." `
-Attachments $attachment

