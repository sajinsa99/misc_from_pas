#!/bin/bash

cp -f /cygdrive/c/terraform/ssh_host_rsa_key /etc/ssh_host_rsa_key
ssh-keygen -f /etc/ssh_host_rsa_key -y > /cygdrive/c/terraform/ssh_host_rsa_key.pub
cp -f /cygdrive/c/terraform/ssh_host_rsa_key.pub /etc/ssh_host_rsa_key.pub
chown cyg_server:Administrators /etc/ssh_host_rsa_key
chown cyg_server:Administrators /etc/ssh_host_rsa_key.pub
chmod 600 /etc/ssh_host_rsa_key
