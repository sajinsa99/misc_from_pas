$attempts = 0
while ($attempts -le 1800) {
  $disk_count = (Get-Disk | Where-Object OperationalStatus -EQ Online | Measure-Object).Count
  Write-Output "$disk_count offline disks attached"
  if ($disk_count -eq 3) {
    break
  }
  Start-Sleep -s 1
}
Write-Output "Done!"
