hanamake_landscape
==================


Definition of the HANA make landscape

Changes to the version of the used job-db-setup can be tested with the docker test sysems:

https://github.wdf.sap.corp/hyper-landscape/service_config

```yaml
## Test HANA on docker
{{ hana_test("prod-build3000",3000, versionVector("hana")) }}
{{ hana_test("prod-build3010",3010, versionVector("hana")) }}
           
## Test LMJ on docker
{{ hana_test("prod-landscape4000",4000,versionVector("hana")) }}
```
